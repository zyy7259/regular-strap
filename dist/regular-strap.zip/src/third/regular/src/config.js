
module.exports = {
  'BEGIN': '{',
  'END': '}',
  'PRECOMPILE': false
}