module.exports = {
  'COMPONENT_TYPE': 1,
  'ELEMENT_TYPE': 2,
  'NAMESPACE': {
    html: "http://www.w3.org/1999/xhtml",
    svg: "http://www.w3.org/2000/svg"
  }
}