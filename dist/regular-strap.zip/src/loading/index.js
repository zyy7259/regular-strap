/*
* @Author: Zhang Yingya(hzzhangyingya)
* @Date:   2016-05-30 14:56:44
* @Last modified by:   zyy
* @Last modified time: 2016-06-22 10:20:64
*/

var tpl = require('./index.html')

module.exports = Regular.extend({
  name: 'loading',
  template: tpl
})
